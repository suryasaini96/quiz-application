package com.wipro.quiz.service;

import java.sql.Date;

import com.wipro.quiz.bean.StudentBean;
import com.wipro.quiz.dao.DAO;

public class Service {
	
	public StudentBean loginUserStudent(int id,String password) {
		   DAO daoObj = new DAO();
		   StudentBean beanObj = daoObj.loginUserStudent(id,password);
		   return beanObj;
		   
	}

	public StudentBean studentProfile(int id) {
		DAO daoObj = new DAO();
		StudentBean beanObj = daoObj.studentProfile(id);
		return beanObj;
	}
	
	public int studentProfileUpdate(int id, String gender, Date dob, long mobile, String email) {
		DAO daoObj = new DAO();
		return daoObj.studentProfileUpdate(id, gender, dob, mobile, email);
	}
	
	
}
