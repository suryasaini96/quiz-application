function afterSubmit(){
		alert(document.getElementById('dob').value);
	}
	
function setSelectedGender(listOfGenders, gender) {
    for(var i=0; i<listOfGenders.options.length; i++ ) {
        if (listOfGenders.options[i].text == gender ) {
        	listOfGenders.options[i].selected = true;
            return;
        }
    }
}

window.onload = setSelectedGender(document.getElementById('gender'),"${student.getGender()}");