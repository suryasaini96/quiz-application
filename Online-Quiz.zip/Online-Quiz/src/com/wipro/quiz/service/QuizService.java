package com.wipro.quiz.service;

import com.wipro.quiz.bean.QuizBean;
import com.wipro.quiz.dao.QuizDAO;

public class QuizService {
	public QuizBean profileInfo(int id) {
		QuizDAO daoObj = new QuizDAO();
		QuizBean beanObj = daoObj.profileInfo(id);
		return beanObj;
	}
	
	public int profileUpdate(int id,String email) {
		QuizDAO daoObj = new QuizDAO();
		return daoObj.profileUpdate(id, email);
	}
}
