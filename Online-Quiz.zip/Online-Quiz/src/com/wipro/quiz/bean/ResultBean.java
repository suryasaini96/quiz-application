package com.wipro.quiz.bean;

public class ResultBean {

	private int id;
	private String topic;
	private int level1;
	private int level2;
	private int level3;
	
	public ResultBean() {
		super();
	}
	
	
	public ResultBean(int id, String topic, int level1, int level2, int level3) {
		super();
		this.id = id;
		this.topic = topic;
		this.level1 = level1;
		this.level2 = level2;
		this.level3 = level3;
	}



	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getTopic() {
		return topic;
	}



	public void setTopic(String topic) {
		this.topic = topic;
	}



	public int getLevel1() {
		return level1;
	}



	public void setLevel1(int level1) {
		this.level1 = level1;
	}



	public int getLevel2() {
		return level2;
	}



	public void setLevel2(int level2) {
		this.level2 = level2;
	}



	public int getLevel3() {
		return level3;
	}



	public void setLevel3(int level3) {
		this.level3 = level3;
	}
	

	
}

