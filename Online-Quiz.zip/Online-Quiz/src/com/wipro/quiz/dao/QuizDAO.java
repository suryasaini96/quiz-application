package com.wipro.quiz.dao;

import java.sql.*;

import com.wipro.quiz.bean.QuizBean;
import com.wipro.quiz.util.QuizDBUtil;

public class QuizDAO {
	public QuizBean profileInfo(int id) {
		QuizBean beanObj = null;
		try {
			Connection connection = QuizDBUtil.getDBConnection();
			String query = "select * from student where id = ?";
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1, id);
			ResultSet result = statement.executeQuery();
			if(result.next()) {
				beanObj = new QuizBean();
				beanObj.setId(result.getInt("ID"));
				beanObj.setFname(result.getString("FNAME"));
				beanObj.setLname(result.getString("LNAME"));
				beanObj.setEmail(result.getString("EMAIL"));
			}
			result.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return beanObj;
	}
	
	public int profileUpdate(int id, String email) {
		try {
			Connection connection = QuizDBUtil.getDBConnection();
			String query = "update student set email = ? where id = ?";
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setString(1, email);
			statement.setInt(2, id);
			int rowsAffected = statement.executeUpdate();
			if(rowsAffected>0) {
				System.out.println("Profile updated.");
				return rowsAffected;
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return 0;

	}
	
	
}
