package com.wipro.quiz.dao;

import java.sql.*;

import com.wipro.quiz.bean.*;
import com.wipro.quiz.util.DBUtil;

public class DAO {
	
	/*        Student methods         */
	
	public StudentBean studentProfile(int id) {
		StudentBean beanObj = null;
		try {
			Connection connection = DBUtil.getDBConnection();
			String query = "select * from student where id = ?";
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1, id);
			ResultSet result = statement.executeQuery();
			if(result.next()) {
				beanObj = new StudentBean();
				beanObj.setId(result.getInt("ID"));
				beanObj.setFname(result.getString("FNAME"));
				beanObj.setLname(result.getString("LNAME"));
				beanObj.setGender(result.getString("GENDER"));
				beanObj.setDob(result.getDate("DOB"));
				beanObj.setMobile(result.getLong("MOBILE"));
				beanObj.setEmail(result.getString("EMAIL"));
				beanObj.setPassword(result.getString("PASSWORD"));
			}
			result.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return beanObj;
	}
	
	public int studentProfileUpdate(int id, String gender, Date dob, long mobile, String email) {
		try {
			Connection connection = DBUtil.getDBConnection();
			String query = "update student set gender = ?, dob = ?, mobile = ?, email = ? where id = ?";
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setString(1, gender);
			statement.setDate(2, dob);
			statement.setLong(3, mobile);
			statement.setString(4, email);
			statement.setInt(5, id);
			
			int rowsAffected = statement.executeUpdate();
			if(rowsAffected>0) {
				System.out.println("Profile updated.");
				return rowsAffected;
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return 0;

	}
	
	/*----------------------------------*/
	
	/*        Professor methods         */
	
	public ProfessorBean professorProfile(int id) {
		ProfessorBean beanObj = null;
		try {
			Connection connection = DBUtil.getDBConnection();
			String query = "select * from professor where id = ?";
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1, id);
			ResultSet result = statement.executeQuery();
			if(result.next()) {
				beanObj = new ProfessorBean();
				beanObj.setId(result.getInt("ID"));
				beanObj.setDept(result.getString("DEPT"));
				beanObj.setFname(result.getString("FNAME"));
				beanObj.setLname(result.getString("LNAME"));
				beanObj.setGender(result.getString("GENDER"));
				beanObj.setDob(result.getDate("DOB"));
				beanObj.setQualification(result.getString("QUALIFICATION"));
				beanObj.setMobile(result.getLong("MOBILE"));
				beanObj.setEmail(result.getString("EMAIL"));
				beanObj.setPassword(result.getString("PASSWORD"));
			}
			result.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return beanObj;
	}
	
	
	
	
}
