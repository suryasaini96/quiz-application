package com.wipro.quiz.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wipro.quiz.bean.QuizBean;
import com.wipro.quiz.service.QuizService;

/**
 * Servlet implementation class profileUpdate
 */
public class profileUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public profileUpdate() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int id = Integer.parseInt(request.getParameter("id"));
		String email = request.getParameter("email");
		
		QuizService service = new QuizService();
		int rowsAffected = service.profileUpdate(id, email);
		
		if(rowsAffected>0) {
			QuizBean newData = new QuizBean();
			newData = service.profileInfo(id);
			if(newData!=null) {
				request.setAttribute("student", newData);
				request.getRequestDispatcher("/StudentProfile.jsp").forward(request, response);
			}
			else {
				PrintWriter out = response.getWriter();
				out.print("DAO Failed");
			}
		}
		else {
			PrintWriter out = response.getWriter();
			out.print("No rows affected!");
		}
		
		
	}

}
