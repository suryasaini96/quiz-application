package com.wipro.quiz.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wipro.quiz.bean.QuizBean;
import com.wipro.quiz.service.QuizService;

/**
 * Servlet implementation class Controller
 * 
 */
//@WebServlet("/QuizController.do")

public class QuizController extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		int id = Integer.parseInt(request.getParameter("id"));
		
		//connecting to service
		QuizService service = new QuizService();
		QuizBean beanObj = service.profileInfo(id);
		
		if (beanObj!=null) { //if DAO request is true
			request.setAttribute("student", beanObj);
			request.getRequestDispatcher("/StudentProfile.jsp").forward(request, response);
		}
		else {
			PrintWriter out = response.getWriter();
			out.print("DAO Failed");
		}

	}

}
