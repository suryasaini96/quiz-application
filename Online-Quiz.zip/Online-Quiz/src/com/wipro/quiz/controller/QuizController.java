package com.wipro.quiz.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wipro.quiz.bean.StudentBean;
import com.wipro.quiz.service.Service;

public class QuizController extends HttpServlet {

	private static final long serialVersionUID = 1L;

	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String buttonTrigger = request.getParameter("submit");
		
		if(buttonTrigger.equals("login")) {
			
			int id = Integer.parseInt(request.getParameter("id"));
			int password = Integer.parseInt(request.getParameter("password"));
			String loginType = request.getParameter("loginType");
			
			Service service = new Service();
			StudentBean beanObj = service.studentProfile(id);
			
			if (beanObj!=null) { //if DAO request is true
				request.setAttribute("student", beanObj);
				request.getRequestDispatcher("/StudentProfile.jsp").forward(request, response);
			}
			else {
				PrintWriter out = response.getWriter();
				out.print("DAO Failed");
			}
		
		}
		
		int id = Integer.parseInt(request.getParameter("id"));
		
		//Connecting to service
		Service service = new Service();
		StudentBean beanObj = service.studentProfile(id);
		
		if (beanObj!=null) { //if DAO request is true
			request.setAttribute("student", beanObj);
			request.getRequestDispatcher("/StudentProfile.jsp").forward(request, response);
		}
		else {
			PrintWriter out = response.getWriter();
			out.print("DAO Failed");
		}

	}

}
