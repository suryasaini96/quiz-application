package com.wipro.quiz.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wipro.quiz.bean.StudentBean;
import com.wipro.quiz.service.Service;

public class StudentController extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String buttonTrigger = request.getParameter("submit");
		String testType = request.getParameter("takeTest");
		PrintWriter out = response.getWriter();
		
		if(buttonTrigger.equals("login")) {
			
			int id = Integer.parseInt(request.getParameter("id"));
			String password = request.getParameter("password");

			Service service = new Service();
			StudentBean beanObj = service.loginUserStudent(id,password);

			if(beanObj!= null) {
				
				HttpSession session = request.getSession();
				session.setAttribute("id", id);
				response.sendRedirect("StudentHome.jsp");
			}
			else {
				out.println("<Script  type=\"text/javascript\">");
				out.println("alert('Invalid UserID or Password');");
				out.println("location='Login.jsp';");
				out.println("</script>");
			}
		}
		
		if(buttonTrigger.equals("register")) {
			
			int id = Integer.parseInt(request.getParameter("id"));
			String fname = request.getParameter("fname");
			String lname = request.getParameter("lname");
			String gender = request.getParameter("gender");
			Date dob = Date.valueOf(request.getParameter("dob"));
			long mobile = Long.parseLong(request.getParameter("mobile"));
			String email = request.getParameter("email");
			String password = request.getParameter("password");
		
			Service service = new Service();
			int rowsInserted = service.registerStudent(id, fname, lname, gender, dob, mobile,  email, password);

			if(rowsInserted>0) {
				response.sendRedirect("Login.jsp");
			}
			else {
				out.println("<Script  type=\"text/javascript\">");
				out.println("alert('Registration failed');");
				out.println("location='StudentRegistration.jsp';");
				out.println("</script>");

			}
		}
		
		if(buttonTrigger.equals("update")) {
			int id = Integer.parseInt(request.getParameter("id"));
			String gender = request.getParameter("gender");
			Date dob = Date.valueOf(request.getParameter("dob"));
			long mobile = Long.parseLong(request.getParameter("mobile"));
			String email = request.getParameter("email");
			String newPassword = request.getParameter("newPassword");
			
			Service service = new Service();
			int rowsAffected=0;
			if (newPassword.length()>0) {
				rowsAffected = service.studentProfileUpdate(id, gender, dob, mobile, email, newPassword);
			}
			else {
				rowsAffected = service.studentProfileUpdate(id, gender, dob, mobile, email);
			}

			if(rowsAffected>0) {
				StudentBean updatedData = new StudentBean();
				updatedData = service.studentProfile(id);
				if(updatedData!=null) {
					request.setAttribute("student", updatedData);
					request.getRequestDispatcher("/StudentProfile.jsp").forward(request, response);
				}
				else {
					out.print("DAO Failed");
				}
			}
			else {
				out.print("No rows affected!");
			}
		}
		
		if(buttonTrigger.equals("ansValidate")) {
			String topic = request.getParameter("topic");
			int stuID = Integer.parseInt(request.getParameter("stuID"));
			int quesID = Integer.parseInt(request.getParameter("quesID"));
			String ans = request.getParameter("ans");
			
			Service service = new Service();
			int rowsInserted = service.answerValidate(topic, stuID, quesID, ans);

			if(rowsInserted>0) {
				response.sendRedirect("Login.jsp");
			}
			else {
				out.println("<Script  type=\"text/javascript\">");
				out.println("alert('Registration failed');");
				out.println("location='StudentRegistration.jsp';");
				out.println("</script>");

			}
		}
		if(testType!= null) {
			HttpSession session = request.getSession();
			session.setAttribute("test", testType);
			response.sendRedirect("Assessment.jsp");
		}
		

	}
	
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		int id=Integer.parseInt(request.getParameter("id"));
		
		//Connecting to service
		Service service = new Service();
		StudentBean beanObj = service.studentProfile(id);
		
		if (beanObj!=null) { //if DAO request is true
			request.setAttribute("student", beanObj);
			request.getRequestDispatcher("/StudentProfile.jsp").forward(request, response);
		}
		else {
			out.print("DAO Failed");
		}
	}

}
