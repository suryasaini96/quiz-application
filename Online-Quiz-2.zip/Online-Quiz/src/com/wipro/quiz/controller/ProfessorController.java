package com.wipro.quiz.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wipro.quiz.bean.*;
import com.wipro.quiz.service.Service;

/**
 * Servlet implementation class ProfessorController
 */
public class ProfessorController extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String buttonTrigger = request.getParameter("submit");
		PrintWriter out = response.getWriter();
		
		if(buttonTrigger.equals("login")) {
			
			int id = Integer.parseInt(request.getParameter("id"));
			String password = request.getParameter("password");
			

			Service service = new Service();
			ProfessorBean beanObj = service.loginUserProfessor(id,password);

			if(beanObj!= null) {
				
				HttpSession session = request.getSession();
				session.setAttribute("id", id);
				response.sendRedirect("ProfessorHome.jsp");
			}
			else {
				out.println("<Script  type=\"text/javascript\">");
				out.println("alert('Invalid UserID or Password');");
				out.println("location='Login.jsp';");
				out.println("</script>");
			}
		}
		
		if(buttonTrigger.equals("register")) {
			
			int id = Integer.parseInt(request.getParameter("id"));
			String dept = request.getParameter("dept");
			String fname = request.getParameter("fname");
			String lname = request.getParameter("lname");
			String gender = request.getParameter("gender");
			Date dob = Date.valueOf(request.getParameter("dob"));
			String qualification = request.getParameter("qualification");
			long mobile = Long.parseLong(request.getParameter("mobile"));
			String email = request.getParameter("email");
			String password = request.getParameter("password");
		
			Service service = new Service();
			int rowsInserted = service.registerProfessor(id, dept, fname, lname, gender, dob, qualification, mobile,  email, password);

			if(rowsInserted>0) {
				response.sendRedirect("Login.jsp");
			}
			else {
				out.println("<Script  type=\"text/javascript\">");
				out.println("alert('Registration failed');");
				out.println("location='ProfessorRegistration.jsp';");
				out.println("</script>");

			}
		}
		
		if(buttonTrigger.equals("update")) {
			int id = Integer.parseInt(request.getParameter("id"));
			String dept = request.getParameter("dept");
			String gender = request.getParameter("gender");
			Date dob = Date.valueOf(request.getParameter("dob"));
			String qualification = request.getParameter("qualification");
			long mobile = Long.parseLong(request.getParameter("mobile"));
			String email = request.getParameter("email");
			String newPassword = request.getParameter("newPassword");
			
			Service service = new Service();
			int rowsAffected=0;
			if (newPassword.length()>0) {
				rowsAffected = service.professorProfileUpdate(id, dept, gender, dob, qualification, mobile, email, newPassword);
			}
			else {
				rowsAffected = service.professorProfileUpdate(id, dept, gender, dob, qualification, mobile, email);
			}

			if(rowsAffected>0) {
				ProfessorBean updatedData = new ProfessorBean();
				updatedData = service.professorProfile(id);
				if(updatedData!=null) {
					request.setAttribute("professor", updatedData);
					request.getRequestDispatcher("/ProfessorProfile.jsp").forward(request, response);
				}
				else {
					out.print("DAO Failed");
				}
			}
			else {
				out.print("No rows affected!");
			}
		}
		
		if(buttonTrigger.equals("createTopic")) {
			
			String topic = request.getParameter("topic");
		
			Service service = new Service();
			service.createTopic(topic);

			out.println("<Script  type=\"text/javascript\">");
			out.println("alert('Topic created.');");
			out.println("location='Topics.jsp';");
			out.println("</script>");
		}
		
		if(buttonTrigger.equals("deleteTopic")) {
			
			String topic = request.getParameter("topic");
		
			Service service = new Service();
			int rowsDeleted = service.deleteTopic(topic);
			
			if(rowsDeleted>0) {
				response.sendRedirect("Home.jsp");
			}
			else {
				out.println("<Script  type=\"text/javascript\">");
				out.println("alert('Registration failed');");
				out.println("location='Topics.jsp';");
				out.println("</script>");
			}
		}
		
		if(buttonTrigger.equals("addQues")) {
			
			String topic = request.getParameter("topic");
			int id = Integer.parseInt(request.getParameter("id"));
			String ques = request.getParameter("ques");
			String op1 = request.getParameter("op1");
			String op2 = request.getParameter("op2");
			String op3 = request.getParameter("op3");
			String op4 = request.getParameter("op3");
			String ans = request.getParameter("ans");
		
			Service service = new Service();
			int rowsInserted = service.addQues(topic, id, ques, op1, op2, op3, op4, ans);
			
			if(rowsInserted>0) {
				out.println("<Script  type=\"text/javascript\">");
				out.println("alert('Question added!');");
				out.println("location='AddQuestion.jsp';");
				out.println("</script>");
			}
			else {
				out.println("<Script  type=\"text/javascript\">");
				out.println("alert('Adding question failed');");
				out.println("location='AddQuestion.jsp';");
				out.println("</script>");
			}
		}

		if(buttonTrigger.equals("deleteQues")) {
			
			String topic = request.getParameter("topic");
			int id = Integer.parseInt(request.getParameter("ques"));
		
			Service service = new Service();
			int rowsDeleted = service.deleteQues(topic, id);
			
			if(rowsDeleted>0) {
				out.println("<Script  type=\"text/javascript\">");
				out.println("alert('Question deleted!');");
				out.println("location='EditQuestion.jsp';");
				out.println("</script>");
			}
			else {
				out.println("<Script  type=\"text/javascript\">");
				out.println("alert('Adding question failed');");
				out.println("location='EditQuestion.jsp';");
				out.println("</script>");
			}
		}

	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		int id = Integer.parseInt(request.getParameter("id"));
		
		//Connecting to service
		Service service = new Service();
		ProfessorBean beanObj = service.professorProfile(id);
		
		if (beanObj!=null) { //if DAO request is true
			request.setAttribute("professor", beanObj);
			request.getRequestDispatcher("/ProfessorProfile.jsp").forward(request, response);
		}
		else {
			out.print("DAO Failed");
		}
	}

}
