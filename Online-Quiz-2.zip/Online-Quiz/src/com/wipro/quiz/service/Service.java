package com.wipro.quiz.service;

import java.sql.Date;

import com.wipro.quiz.bean.*;
import com.wipro.quiz.dao.DAO;

public class Service {
	
	/* ------------------- STUDENT ---------------------- */
	
	public StudentBean loginUserStudent(int id,String password) {
		   DAO daoObj = new DAO();
		   StudentBean beanObj = daoObj.loginUserStudent(id,password);
		   return beanObj;   
	}

	public StudentBean studentProfile(int id) {
		DAO daoObj = new DAO();
		StudentBean beanObj = daoObj.studentProfile(id);
		return beanObj;
	}
	
	public int studentProfileUpdate(int id, String gender, Date dob, long mobile, String email) {
		DAO daoObj = new DAO();
		return daoObj.studentProfileUpdate(id, gender, dob, mobile, email);
	}
	
	public int studentProfileUpdate(int id, String gender, Date dob, long mobile, String email, String newPassword) {
		DAO daoObj = new DAO();
		return daoObj.studentProfileUpdate(id, gender, dob, mobile, email, newPassword);
	}
	
	public int registerStudent(int id, String fname, String lname, String gender, Date dob, long mobile, String email, String password) {
		DAO daoObj = new DAO();
		return daoObj.registerStudent(id, fname, lname, gender, dob, mobile,  email, password);
	}
	
	public int answerValidate(String topic, int stuID, int quesID, String ans) {
		DAO daoObj = new DAO();
		return daoObj.answerValidate(topic, stuID, quesID, ans);
	}
	
	
    /* ------------------- PROFESSOR ---------------------- */
	
	public ProfessorBean loginUserProfessor(int id,String password) {
		   DAO daoObj = new DAO();
		   ProfessorBean beanObj = daoObj.loginUserProfessor(id,password);
		   return beanObj;	   
	}
	
	public ProfessorBean professorProfile(int id) {
		DAO daoObj = new DAO();
		ProfessorBean beanObj = daoObj.professorProfile(id);
		return beanObj;
	}
	
	public int registerProfessor(int id, String dept, String fname, String lname, String gender, Date dob, String qualification, long mobile, String email, String password) {
		DAO daoObj = new DAO();
		return daoObj.registerProfessor(id, dept, fname, lname, gender, dob,qualification, mobile,  email, password);
	}
	
	public int professorProfileUpdate(int id, String dept, String gender, Date dob, String qualification, long mobile, String email) {
		DAO daoObj = new DAO();
		return daoObj.professorProfileUpdate(id, dept, gender, dob, qualification, mobile, email);
	}
	
	public int professorProfileUpdate(int id, String dept, String gender, Date dob, String qualification, long mobile, String email, String newPassword) {
		DAO daoObj = new DAO();
		return daoObj.professorProfileUpdate(id, dept, gender, dob, qualification, mobile, email, newPassword);
	}
	
	public void createTopic(String topic) {
		DAO daoObj = new DAO();
		daoObj.createTopic(topic);
	}
	
	public int deleteTopic(String topic) {
		DAO daoObj = new DAO();
		return daoObj.deleteTopic(topic);
	}
	
	public int addQues(String topic, int id, String ques, String op1, String op2, String op3, String op4, String ans) {
		DAO daoObj = new DAO();
		return daoObj.addQues(topic, id, ques, op1, op2, op3, op4, ans);
	}
	
	public int deleteQues(String topic, int id) {
		DAO daoObj = new DAO();
		return daoObj.deleteQues(topic, id);
	}
	
	
	
}
