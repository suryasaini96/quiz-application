var timer;     
var min = 59;
var sec = 60;
var time = new Date();
function f1() {
    f2();
    //document.getElementById("starttime").innerHTML = "Your started your Exam at " + time.getHours() + ":" + time.getMinutes();
}
function f2() {
    if (parseInt(sec) > 0) {
        sec = parseInt(sec) - 1;
        document.getElementById("showtime").innerHTML = "Time left: " + min + " min   " + sec + " seconds";
        timer = setTimeout("f2()", 1000);
    }
    else {
        if (parseInt(sec) == 0) {
            min = parseInt(min) - 1;
            if (parseInt(min) == -1) {
                clearTimeout(timer);
                alert('Time up!');
                location.href = "#";
            }
            else {
                sec = 60;
                document.getElementById("showtime").innerHTML = "Time left: " + min + " min   " + sec + " seconds";
                timer = setTimeout("f2()", 1000);
            }
        }
    }
}