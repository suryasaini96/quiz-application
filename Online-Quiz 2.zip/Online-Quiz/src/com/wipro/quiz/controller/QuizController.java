package com.wipro.quiz.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wipro.quiz.bean.StudentBean;
import com.wipro.quiz.service.Service;

public class QuizController extends HttpServlet {

	private static final long serialVersionUID = 1L;

	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String buttonTrigger = request.getParameter("submit");
		PrintWriter out = response.getWriter();
		
		if(buttonTrigger.equals("login")) {
			
			int id = Integer.parseInt(request.getParameter("id"));
			String password = request.getParameter("password");

			Service service = new Service();
			StudentBean beanObj = service.loginUserStudent(id,password);

			if(beanObj!= null) {
				
				HttpSession session = request.getSession();
				session.setAttribute("id", id);
				response.sendRedirect("StudentHome.jsp");
				//request.setAttribute("id", id);
				//request.getRequestDispatcher("/Session.jsp").forward(request, response);


			}
			else {
				out.println("<Script  type=\"text/javascript\">");
				out.println("alert('Invalid Userid or Password');");
				out.println("location='Login.jsp';");
				out.println("</script>");

			}
		}
		
		/*int id = Integer.parseInt(request.getParameter("id"));
		
		//Connecting to service
		Service service = new Service();
		StudentBean beanObj = service.studentProfile(id);
		
		if (beanObj!=null) { //if DAO request is true
			request.setAttribute("student", beanObj);
			request.getRequestDispatcher("/StudentProfile.jsp").forward(request, response);
		}
		else {
			//PrintWriter out = response.getWriter();
			out.print("DAO Failed");
		}*/

	}
	
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		PrintWriter out = response.getWriter();
		int id = Integer.parseInt(request.getParameter("id"));
		
		//Connecting to service
		Service service = new Service();
		StudentBean beanObj = service.studentProfile(id);
		
		if (beanObj!=null) { //if DAO request is true
			request.setAttribute("student", beanObj);
			request.getRequestDispatcher("/StudentProfile.jsp").forward(request, response);
		}
		else {
			//PrintWriter out = response.getWriter();
			out.print("DAO Failed");
		}

	}
	

}
