package com.wipro.quiz.service;

import java.sql.Date;

import com.wipro.quiz.bean.*;
import com.wipro.quiz.dao.DAO;

public class Service {
	
	public StudentBean loginUserStudent(int id,String password) {
		   DAO daoObj = new DAO();
		   StudentBean beanObj = daoObj.loginUserStudent(id,password);
		   return beanObj;
		   
	}

	public StudentBean studentProfile(int id) {
		DAO daoObj = new DAO();
		StudentBean beanObj = daoObj.studentProfile(id);
		return beanObj;
	}
	
	public int studentProfileUpdate(int id, String gender, Date dob, long mobile, String email) {
		DAO daoObj = new DAO();
		return daoObj.studentProfileUpdate(id, gender, dob, mobile, email);
	}
	
	public int registerStudent(int id, String fname, String lname, String gender, Date dob, long mobile, String email, String password) {
		DAO daoObj = new DAO();
		return daoObj.registerStudent(id, fname, lname, gender, dob, mobile,  email, password);
	}
    /* ------------------- PROFESSOR ---------------------- */
	
	public ProfessorBean loginUserProfessor(int id,String password) {
		   DAO daoObj = new DAO();
		   ProfessorBean beanObj = daoObj.loginUserProfessor(id,password);
		   return beanObj;
		   
	}
	
	public ProfessorBean professorProfile(int id) {
		DAO daoObj = new DAO();
		ProfessorBean beanObj = daoObj.professorProfile(id);
		return beanObj;
	}
	
	public int registerProfessor(int id, String dept, String fname, String lname, String gender, Date dob, String qualification, long mobile, String email, String password) {
		DAO daoObj = new DAO();
		return daoObj.registerProfessor(id, dept, fname, lname, gender, dob,qualification, mobile,  email, password);
	}
	
}
