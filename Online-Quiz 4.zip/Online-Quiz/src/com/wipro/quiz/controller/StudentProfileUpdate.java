package com.wipro.quiz.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wipro.quiz.bean.StudentBean;
import com.wipro.quiz.service.Service;

public class StudentProfileUpdate extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int id = Integer.parseInt(request.getParameter("id"));
		String gender = request.getParameter("gender");
		Date dob = Date.valueOf(request.getParameter("dob"));
		long mobile = Long.parseLong(request.getParameter("mobile"));
		String email = request.getParameter("email");
		
		Service service = new Service();
		int rowsAffected = service.studentProfileUpdate(id, gender, dob, mobile, email);
		
		if(rowsAffected>0) {
			StudentBean updatedData = new StudentBean();
			updatedData = service.studentProfile(id);
			if(updatedData!=null) {
				request.setAttribute("student", updatedData);
				request.getRequestDispatcher("/StudentProfile.jsp").forward(request, response);
			}
			else {
				PrintWriter out = response.getWriter();
				out.print("DAO Failed");
			}
		}
		else {
			PrintWriter out = response.getWriter();
			out.print("No rows affected!");
		}
		
		
	}

}
