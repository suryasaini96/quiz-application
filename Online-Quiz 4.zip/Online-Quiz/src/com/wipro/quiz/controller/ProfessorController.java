package com.wipro.quiz.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wipro.quiz.bean.*;
import com.wipro.quiz.service.Service;

/**
 * Servlet implementation class ProfessorController
 */
public class ProfessorController extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String buttonTrigger = request.getParameter("submit");
		PrintWriter out = response.getWriter();
		
		if(buttonTrigger.equals("login")) {
			
			int id = Integer.parseInt(request.getParameter("id"));
			String password = request.getParameter("password");
			

			Service service = new Service();
			ProfessorBean beanObj = service.loginUserProfessor(id,password);

			if(beanObj!= null) {
				
				HttpSession session = request.getSession();
				session.setAttribute("id", id);
				response.sendRedirect("ProfessorHome.jsp");
			}
			else {
				out.println("<Script  type=\"text/javascript\">");
				out.println("alert('Invalid UserID or Password');");
				out.println("location='Login.jsp';");
				out.println("</script>");
			}
		}
		
		if(buttonTrigger.equals("register")) {
			
			int id = Integer.parseInt(request.getParameter("id"));
			String dept = request.getParameter("dept");
			String fname = request.getParameter("fname");
			String lname = request.getParameter("lname");
			String gender = request.getParameter("gender");
			Date dob = Date.valueOf(request.getParameter("dob"));
			String qualification = request.getParameter("qualification");
			long mobile = Long.parseLong(request.getParameter("mobile"));
			String email = request.getParameter("email");
			String password = request.getParameter("password");
		
			Service service = new Service();
			int rowsInserted = service.registerProfessor(id, dept, fname, lname, gender, dob, qualification, mobile,  email, password);

			if(rowsInserted>0) {
				response.sendRedirect("Login.jsp");
			}
			else {
				out.println("<Script  type=\"text/javascript\">");
				out.println("alert('Registration failed');");
				out.println("location='ProfessorRegistration.jsp';");
				out.println("</script>");

			}
		}

	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		int id = Integer.parseInt(request.getParameter("id"));
		
		//Connecting to service
		Service service = new Service();
		ProfessorBean beanObj = service.professorProfile(id);
		
		if (beanObj!=null) { //if DAO request is true
			request.setAttribute("professor", beanObj);
			request.getRequestDispatcher("/ProfessorProfile.jsp").forward(request, response);
		}
		else {
			out.print("DAO Failed");
		}
	}

}
