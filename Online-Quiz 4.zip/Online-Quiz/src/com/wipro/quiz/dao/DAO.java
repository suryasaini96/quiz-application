package com.wipro.quiz.dao;

import java.sql.*;

import com.wipro.quiz.bean.*;
import com.wipro.quiz.util.DBUtil;

public class DAO {
	
	/*        Student methods         */
	
	public StudentBean loginUserStudent(int id,String password) {
		StudentBean beanObj = null;
		try {			
			Connection connection = DBUtil.getDBConnection();
			String query = "select * from student where id = ? and password = ?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, id);
			preparedStatement.setString(2, password);
			ResultSet resultSet = preparedStatement.executeQuery();
			if(resultSet.next()) {
				beanObj = new StudentBean();
				beanObj.setId(resultSet.getInt("id"));
				beanObj.setPassword(resultSet.getString("password"));				
			}
			resultSet.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return beanObj;
	}
	
	public StudentBean studentProfile(int id) {
		StudentBean beanObj = null;
		try {
			Connection connection = DBUtil.getDBConnection();
			String query = "select * from student where id = ?";
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1, id);
			ResultSet result = statement.executeQuery();
			if(result.next()) {
				beanObj = new StudentBean();
				beanObj.setId(result.getInt("ID"));
				beanObj.setFname(result.getString("FNAME"));
				beanObj.setLname(result.getString("LNAME"));
				beanObj.setGender(result.getString("GENDER"));
				beanObj.setDob(result.getDate("DOB"));
				beanObj.setMobile(result.getLong("MOBILE"));
				beanObj.setEmail(result.getString("EMAIL"));
				beanObj.setPassword(result.getString("PASSWORD"));
			}
			result.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return beanObj;
	}
	
	public int studentProfileUpdate(int id, String gender, Date dob, long mobile, String email) {
		try {
			Connection connection = DBUtil.getDBConnection();
			String query = "update student set gender = ?, dob = ?, mobile = ?, email = ? where id = ?";
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setString(1, gender);
			statement.setDate(2, dob);
			statement.setLong(3, mobile);
			statement.setString(4, email);
			statement.setInt(5, id);
			
			int rowsAffected = statement.executeUpdate();
			if(rowsAffected>0) {
				System.out.println("Profile updated.");
				return rowsAffected;
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return 0;

	}
	
	public int registerStudent(int id, String fname, String lname, String gender, Date dob, long mobile, String email, String password) {
		try {
			Connection connection = DBUtil.getDBConnection();
			String query = "insert into student values (?,?,?,?,?,?,?,?)";
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1, id);
			statement.setString(2, fname);
			statement.setString(3, lname);
			statement.setString(4, gender);
			statement.setDate(5, dob);
			statement.setLong(6, mobile);
			statement.setString(7, email);
			statement.setString(8, password);
			
			int rowsInserted = statement.executeUpdate();
			if(rowsInserted>0) {
				System.out.println("Student registered.");
				return rowsInserted;
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return 0;

	}
	
	/*----------------------------------*/
	
	/*        Professor methods         */
	
	public ProfessorBean loginUserProfessor(int id,String password) {
		ProfessorBean beanObj = null;
		try {			
			Connection connection = DBUtil.getDBConnection();
			String query = "select * from professor where id = ? and password = ?";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, id);
			preparedStatement.setString(2, password);
			ResultSet resultSet = preparedStatement.executeQuery();
			if(resultSet.next()) {
				beanObj = new ProfessorBean();
				beanObj.setId(resultSet.getInt("id"));
				beanObj.setPassword(resultSet.getString("password"));				
			}
			resultSet.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return beanObj;
	}
	
	public ProfessorBean professorProfile(int id) {
		ProfessorBean beanObj = null;
		try {
			Connection connection = DBUtil.getDBConnection();
			String query = "select * from professor where id = ?";
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1, id);
			ResultSet result = statement.executeQuery();
			if(result.next()) {
				beanObj = new ProfessorBean();
				beanObj.setId(result.getInt("ID"));
				beanObj.setDept(result.getString("DEPT"));
				beanObj.setFname(result.getString("FNAME"));
				beanObj.setLname(result.getString("LNAME"));
				beanObj.setGender(result.getString("GENDER"));
				beanObj.setDob(result.getDate("DOB"));
				beanObj.setQualification(result.getString("QUALIFICATION"));
				beanObj.setMobile(result.getLong("MOBILE"));
				beanObj.setEmail(result.getString("EMAIL"));
				beanObj.setPassword(result.getString("PASSWORD"));
			}
			result.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return beanObj;
	}
	
	public int registerProfessor(int id, String dept, String fname, String lname, String gender, Date dob, String qualification, long mobile, String email, String password) {
		try {
			Connection connection = DBUtil.getDBConnection();
			String query = "insert into professor values (?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1, id);
			statement.setString(2, dept);
			statement.setString(3, fname);
			statement.setString(4, lname);
			statement.setString(5, gender);
			statement.setDate(6, dob);
			statement.setString(7, qualification);
			statement.setLong(8, mobile);
			statement.setString(9, email);
			statement.setString(10, password);
			
			int rowsInserted = statement.executeUpdate();
			if(rowsInserted>0) {
				System.out.println("Professor registered.");
				return rowsInserted;
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return 0;

	}
	
	
	
	
}
